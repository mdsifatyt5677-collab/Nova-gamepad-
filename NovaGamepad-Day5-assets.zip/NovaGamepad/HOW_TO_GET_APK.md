# How to get a real, installable Nova Gamepad APK

I can't generate the .apk file myself — my environment has no Android SDK
and no internet access. Below are two ways to get a real one. Option A
needs zero coding knowledge, just a web browser.

---

## Option A — GitHub builds it for you (no coding, no installs)

1. Go to https://github.com and create a free account if you don't have one.
2. Click the "+" in the top-right → "New repository". Name it anything
   (e.g. "nova-gamepad"). Click "Create repository".
3. On the new repo's page, click "uploading an existing file" (or
   "Add file" → "Upload files").
4. Unzip NovaGamepad-Day5-assets.zip on your computer, then drag the whole
   unzipped "NovaGamepad" folder's contents into the browser upload area
   (drag the files/folders — app, gradle, .github, build.gradle.kts,
   settings.gradle.kts, gradle.properties — not the outer zip).
5. Scroll down, click "Commit changes".
6. Click the "Actions" tab at the top of the repo. A workflow called
   "Build Nova Gamepad Debug APK" should already be running (it starts
   automatically after step 5). If it isn't, click it in the left list,
   then click "Run workflow".
7. Wait 3-5 minutes for the green checkmark.
8. Click the finished run, scroll down to "Artifacts", and download
   "NovaGamepad-debug-apk" — it's a zip containing app-debug.apk.
9. Get that .apk onto your phone any way you like (email it to yourself,
   upload to Google Drive and download on the phone, etc.).
10. On your phone, tap the .apk file. Android will ask to allow
    installing from this source the first time — allow it, then Install.

---

## Option B — Android Studio (if you're open to installing one thing)

1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip NovaGamepad-Day5-assets.zip and choose File → Open in Android Studio
   (not "New Project") — select the unzipped NovaGamepad folder.
3. Let it sync (first time takes a few minutes).
4. Build → Build Bundle(s)/APK(s) → Build APK(s).
5. Click "locate" in the popup to find app-debug.apk, then copy it to
   your phone and install it as in step 10 above.

---

Either way you end up with the same file: a debug APK you can install
directly on your phone. Option A is slower per-build but needs nothing
installed; Option B is faster to iterate on if you plan to keep changing
the app.
