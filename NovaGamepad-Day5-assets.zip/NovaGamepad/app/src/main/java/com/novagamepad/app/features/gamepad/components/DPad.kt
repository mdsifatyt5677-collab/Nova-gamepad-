package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * D-pad matching the reference: four separate angular, outward-pointing
 * buttons (not a plain four-square grid) arranged in a cross with a gap
 * between them, each individually touchable with its own arrow icon.
 */
@Composable
fun DPad(
    size: Dp,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier
) {
    val cell = size * 0.42f
    val gap = size * 0.03f

    Box(modifier = modifier.size(size)) {
        DPadButton(
            control = GamepadControl.DPAD_UP,
            uiState = uiState,
            icon = Icons.Filled.KeyboardArrowUp,
            shape = pointedShape(Point.UP),
            modifier = Modifier.align(Alignment.TopCenter).padding(bottom = gap).size(cell)
        )
        DPadButton(
            control = GamepadControl.DPAD_DOWN,
            uiState = uiState,
            icon = Icons.Filled.KeyboardArrowDown,
            shape = pointedShape(Point.DOWN),
            modifier = Modifier.align(Alignment.BottomCenter).padding(top = gap).size(cell)
        )
        DPadButton(
            control = GamepadControl.DPAD_LEFT,
            uiState = uiState,
            icon = Icons.Filled.KeyboardArrowLeft,
            shape = pointedShape(Point.LEFT),
            modifier = Modifier.align(Alignment.CenterStart).padding(end = gap).size(cell)
        )
        DPadButton(
            control = GamepadControl.DPAD_RIGHT,
            uiState = uiState,
            icon = Icons.Filled.KeyboardArrowRight,
            shape = pointedShape(Point.RIGHT),
            modifier = Modifier.align(Alignment.CenterEnd).padding(start = gap).size(cell)
        )
    }
}

@Composable
private fun DPadButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    icon: ImageVector,
    shape: Shape,
    modifier: Modifier
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = shape,
        modifier = modifier
    ) {
        Icon(imageVector = icon, contentDescription = control.label)
    }
}

private enum class Point { UP, DOWN, LEFT, RIGHT }

/**
 * A rounded pentagon whose tip points outward in [point]'s direction —
 * the angular "house" shape the D-pad buttons use in the reference, in
 * place of a plain rounded rectangle.
 */
private fun pointedShape(point: Point): Shape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    val tip = 0.32f
    when (point) {
        Point.UP -> {
            moveTo(w * 0.5f, 0f)
            lineTo(w, h * tip)
            lineTo(w, h)
            lineTo(0f, h)
            lineTo(0f, h * tip)
            close()
        }
        Point.DOWN -> {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * (1 - tip))
            lineTo(w * 0.5f, h)
            lineTo(0f, h * (1 - tip))
            close()
        }
        Point.LEFT -> {
            moveTo(0f, h * 0.5f)
            lineTo(w * tip, 0f)
            lineTo(w, 0f)
            lineTo(w, h)
            lineTo(w * tip, h)
            close()
        }
        Point.RIGHT -> {
            moveTo(w, h * 0.5f)
            lineTo(w * (1 - tip), h)
            lineTo(0f, h)
            lineTo(0f, 0f)
            lineTo(w * (1 - tip), 0f)
            close()
        }
    }
}
