package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaWhite

/** Small pill toolbar shown only while Edit Mode is on. */
@Composable
fun EditModeToolbar(
    onMapping: () -> Unit,
    onSave: () -> Unit,
    onReset: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(NovaSurface)
            .border(1.dp, NovaControllerOutline, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ToolbarLabel("Mapping", onMapping)
        ToolbarLabel("Save", onSave)
        ToolbarLabel("Reset", onReset)
        ToolbarLabel("Done", onDone, highlight = true)
    }
}

@Composable
private fun ToolbarLabel(label: String, onClick: () -> Unit, highlight: Boolean = false) {
    Text(
        text = label,
        color = if (highlight) NovaOrange else NovaWhite,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp)
    )
}
