package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaViolet
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Top-left "utility" icon. Doubles as the way back to Home — the
 * controller layout has no separate back arrow slot, and adding one would
 * mean introducing an element that isn't in the reference. The Android
 * system Back gesture/button still works everywhere via
 * [androidx.activity.compose.BackHandler] regardless of this icon.
 *
 * Day 5 asset-sheet pass: the closest matching asset for this button is
 * a literal back-arrow glyph (its actual function), replacing the earlier
 * overlapping-squares placeholder icon. Position, size, and behavior
 * (still calls [onClick]) are unchanged.
 */
@Composable
fun UtilityIconButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .border(1.5.dp, NovaControllerOutline, CircleShape)
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back to Home",
            tint = NovaWhite,
            modifier = Modifier.size(17.dp)
        )
    }
}

/** Static "⌨ Keyboard" indicator from the top-center of the reference. */
@Composable
fun KeyboardIndicator(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .border(1.5.dp, NovaControllerOutline, RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Keyboard,
            contentDescription = null,
            tint = NovaWhite,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = "Keyboard",
            style = MaterialTheme.typography.bodyMedium,
            color = NovaWhite,
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

/**
 * The top-right three-line ("hamburger") icon. Tapping it hides or shows
 * the debug status box (Pressed: / Joystick: readout) — it doesn't affect
 * the controller itself.
 */
@Composable
fun StatusToggleButton(
    isStatusVisible: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onToggle,
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .border(1.5.dp, if (isStatusVisible) NovaOrange else NovaControllerOutline, CircleShape)
    ) {
        Icon(
            imageVector = Icons.Outlined.Menu,
            contentDescription = "Toggle status box",
            tint = if (isStatusVisible) NovaOrange else NovaWhite,
            modifier = Modifier.size(18.dp)
        )
    }
}

private val HexagonShape: Shape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    moveTo(w * 0.5f, 0f)
    lineTo(w, h * 0.25f)
    lineTo(w, h * 0.75f)
    lineTo(w * 0.5f, h)
    lineTo(0f, h * 0.75f)
    lineTo(0f, h * 0.25f)
    close()
}

/**
 * Toggles Edit Mode / Play Mode — see
 * [com.novagamepad.app.features.gamepad.model.EditorState].
 *
 * Day 5 asset-sheet pass: the closest matching asset for this control is
 * a labeled pill ("Edit Mode", pencil icon, orange outline+text when
 * active) rather than a bare icon circle, so the shape/label follow that
 * asset — this is the one place a control's width changes as part of the
 * swap, since the reference's own button for this function is a pill, not
 * a circle. Still a single toggle button, same position, same behavior.
 */
@Composable
fun EditModeToggleButton(
    isEditMode: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val color = if (isEditMode) NovaOrange else NovaWhite
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .border(1.5.dp, if (isEditMode) NovaOrange else NovaControllerOutline, RoundedCornerShape(50))
            .clickable(onClick = onToggle)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Edit,
            contentDescription = if (isEditMode) "Exit Edit Mode" else "Enter Edit Mode",
            tint = color,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = "Edit Mode",
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

/**
 * Starts/stops the floating overlay window — see
 * [com.novagamepad.app.features.overlay.GamepadOverlayService]. Requesting
 * the overlay permission (if not already granted) is handled by the
 * caller; this button just reflects and toggles the running state.
 *
 * Day 5 asset-sheet pass: the closest matching asset icons for
 * start/stop are a play triangle and a stop square, replacing the
 * earlier generic "layers" icon.
 */
@Composable
fun OverlayToggleButton(
    isOverlayRunning: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onToggle,
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .border(1.5.dp, if (isOverlayRunning) NovaOrange else NovaControllerOutline, CircleShape)
    ) {
        Icon(
            imageVector = if (isOverlayRunning) Icons.Filled.Stop else Icons.Filled.PlayArrow,
            contentDescription = if (isOverlayRunning) "Stop Overlay" else "Start Overlay",
            tint = if (isOverlayRunning) NovaOrange else NovaWhite,
            modifier = Modifier.size(17.dp)
        )
    }
}

/**
 * Small decorative Nova brand mark, far top-right in the reference.
 *
 * Day 5 asset-sheet pass: the reference's own hex mark uses a violet dot,
 * not orange — matched here since that's this element's own specific
 * asset color, while the rest of the controller keeps the orange accent.
 */
@Composable
fun NovaHexMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(30.dp)
            .clip(HexagonShape)
            .border(1.5.dp, NovaControllerOutline, HexagonShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(NovaViolet)
        )
    }
}
