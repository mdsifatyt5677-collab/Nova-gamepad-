package com.novagamepad.app.data.storage

import android.content.Context
import android.util.Log
import com.novagamepad.app.data.model.ControlTransform
import com.novagamepad.app.data.model.ControllerLayoutConfig
import com.novagamepad.app.data.model.JoystickSettings
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.features.gamepad.model.GamepadControl
import org.json.JSONObject

/**
 * Local persistence for the controller layout: element positions/sizes/
 * opacity/visibility, button key-mappings, global size/opacity, and each
 * joystick's sensitivity/dead-zone. Uses SharedPreferences with a hand-
 * rolled JSON blob rather than a database or a serialization library —
 * the data is small and simple enough that this keeps dependencies at
 * zero. SharedPreferences is backed by a file on disk, so a saved layout
 * survives both an app restart and a phone restart.
 *
 * Every field is read defensively with a fallback default, so a save
 * from an older version of the app (missing the newer fields) still
 * loads correctly instead of crashing or losing data.
 */
object ControllerLayoutStorage {
    private const val PREFS_NAME = "nova_gamepad_layout"
    private const val KEY_CONFIG = "config_json"
    private const val TAG = "ControllerLayoutStorage"

    fun save(context: Context, config: ControllerLayoutConfig): Boolean {
        return try {
            val json = toJson(config)
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_CONFIG, json.toString())
                .apply()
            true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save controller layout", e)
            false
        }
    }

    /** Returns null if there is no saved layout, or if it couldn't be read — never throws. */
    fun load(context: Context): ControllerLayoutConfig? {
        return try {
            val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_CONFIG, null) ?: return null
            fromJson(JSONObject(raw))
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load saved controller layout, using defaults", e)
            null
        }
    }

    fun clear(context: Context) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_CONFIG)
                .apply()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear saved controller layout", e)
        }
    }

    private fun toJson(config: ControllerLayoutConfig): JSONObject {
        val transformsJson = JSONObject()
        for ((element, t) in config.transforms) {
            val obj = JSONObject()
            obj.put("x", t.offsetXDp.toDouble())
            obj.put("y", t.offsetYDp.toDouble())
            obj.put("scale", t.scale.toDouble())
            obj.put("opacity", t.opacity.toDouble())
            obj.put("visible", t.isVisible)
            transformsJson.put(element.name, obj)
        }

        val mappingsJson = JSONObject()
        for ((control, key) in config.mappings) {
            mappingsJson.put(control.name, key)
        }

        val leftStickJson = JSONObject().apply {
            put("sensitivity", config.leftStickSettings.sensitivity.toDouble())
            put("deadzone", config.leftStickSettings.deadzone.toDouble())
        }
        val rightStickJson = JSONObject().apply {
            put("sensitivity", config.rightStickSettings.sensitivity.toDouble())
            put("deadzone", config.rightStickSettings.deadzone.toDouble())
        }

        return JSONObject().apply {
            put("transforms", transformsJson)
            put("mappings", mappingsJson)
            put("globalScale", config.globalScale.toDouble())
            put("globalOpacity", config.globalOpacity.toDouble())
            put("leftStick", leftStickJson)
            put("rightStick", rightStickJson)
        }
    }

    private fun fromJson(json: JSONObject): ControllerLayoutConfig {
        val transforms = mutableMapOf<LayoutElement, ControlTransform>()
        val transformsJson = json.optJSONObject("transforms")
        if (transformsJson != null) {
            val keys = transformsJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val element = try {
                    LayoutElement.valueOf(key)
                } catch (e: IllegalArgumentException) {
                    null
                }
                val obj = transformsJson.optJSONObject(key)
                if (element != null && obj != null) {
                    transforms[element] = ControlTransform(
                        offsetXDp = obj.optDouble("x", 0.0).toFloat(),
                        offsetYDp = obj.optDouble("y", 0.0).toFloat(),
                        scale = obj.optDouble("scale", 1.0).toFloat(),
                        opacity = obj.optDouble("opacity", 1.0).toFloat(),
                        isVisible = obj.optBoolean("visible", true)
                    )
                }
            }
        }

        val mappings = mutableMapOf<GamepadControl, String>()
        val mappingsJson = json.optJSONObject("mappings")
        if (mappingsJson != null) {
            val keys = mappingsJson.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val control = try {
                    GamepadControl.valueOf(key)
                } catch (e: IllegalArgumentException) {
                    null
                }
                val value = mappingsJson.optString(key, "")
                if (control != null && value.isNotEmpty()) {
                    mappings[control] = value
                }
            }
        }

        val leftStickJson = json.optJSONObject("leftStick")
        val leftStick = JoystickSettings(
            sensitivity = leftStickJson?.optDouble("sensitivity", 1.0)?.toFloat() ?: 1f,
            deadzone = leftStickJson?.optDouble("deadzone", 0.12)?.toFloat() ?: 0.12f
        )
        val rightStickJson = json.optJSONObject("rightStick")
        val rightStick = JoystickSettings(
            sensitivity = rightStickJson?.optDouble("sensitivity", 1.0)?.toFloat() ?: 1f,
            deadzone = rightStickJson?.optDouble("deadzone", 0.12)?.toFloat() ?: 0.12f
        )

        return ControllerLayoutConfig(
            transforms = transforms,
            mappings = mappings,
            globalScale = json.optDouble("globalScale", 1.0).toFloat(),
            globalOpacity = json.optDouble("globalOpacity", 1.0).toFloat(),
            leftStickSettings = leftStick,
            rightStickSettings = rightStick
        )
    }
}
