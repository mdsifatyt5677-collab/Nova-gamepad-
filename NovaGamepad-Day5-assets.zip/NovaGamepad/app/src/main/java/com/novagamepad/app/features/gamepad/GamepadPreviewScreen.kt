package com.novagamepad.app.features.gamepad

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.data.storage.ControllerLayoutStorage
import com.novagamepad.app.features.gamepad.components.ActionButtons
import com.novagamepad.app.features.gamepad.components.DPad
import com.novagamepad.app.features.gamepad.components.EditModeToggleButton
import com.novagamepad.app.features.gamepad.components.EditModeToolbar
import com.novagamepad.app.features.gamepad.components.EditPanel
import com.novagamepad.app.features.gamepad.components.EditableElement
import com.novagamepad.app.features.gamepad.components.Joystick
import com.novagamepad.app.features.gamepad.components.KeyMappingPanel
import com.novagamepad.app.features.gamepad.components.KeyboardIndicator
import com.novagamepad.app.features.gamepad.components.NovaHexMark
import com.novagamepad.app.features.gamepad.components.OverlayToggleButton
import com.novagamepad.app.features.gamepad.components.ShoulderCluster
import com.novagamepad.app.features.gamepad.components.StatusOverlay
import com.novagamepad.app.features.gamepad.components.StatusToggleButton
import com.novagamepad.app.features.gamepad.components.SystemButtonsRow
import com.novagamepad.app.features.gamepad.components.UtilityIconButton
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.rememberGamepadUiState
import com.novagamepad.app.features.overlay.GamepadOverlayService
import com.novagamepad.app.features.overlay.OverlayPermission
import com.novagamepad.app.ui.theme.NovaBackground

/**
 * Gamepad preview / test controller — the full Day 3/4 MVP surface.
 *
 * [editor] is passed in rather than created here (as of Day 4): it's
 * created once in MainActivity and shared with the Settings screen, so a
 * change made there (say, the sensitivity slider) is immediately live
 * here without needing a reload, and "Open Controller Editor" from
 * Settings lands on exactly the state you left it in.
 *
 * Two modes, switched with the pencil icon in the top row:
 *  - **Play mode** (default): exactly Day 2's behavior. Every button and
 *    both joysticks work normally; [EditableElement] adds no gestures at
 *    all here, so nothing about Day 2's feel changed.
 *  - **Edit mode**: tap any element to select it (orange outline), drag it
 *    to reposition, or use the panel that appears to nudge its position,
 *    step its size/opacity, show/hide it, or set its key mapping. The
 *    toolbar's Mapping button opens the full key-mapping list; Save
 *    writes everything to disk (survives app and phone restart); Reset
 *    restores the Day 2 default positions (mappings and joystick
 *    sensitivity/dead-zone are kept).
 *
 * NOTE ON KEY MAPPING: assigning "A → Space" here only stores that
 * mapping — see [com.novagamepad.app.features.gamepad.components.KeyMappingPanel].
 * Nothing in this app injects that keystroke into another app. Doing that
 * for real would require an Accessibility Service, Shizuku, or root,
 * none of which this project implements, per the instruction not to
 * fake input injection.
 *
 * NOTE ON THE OVERLAY BUTTON: starts/stops a real floating window over
 * other apps (see [com.novagamepad.app.features.overlay.GamepadOverlayService]
 * for exactly what that does and doesn't do).
 */
@Composable
fun GamepadPreviewScreen(editor: EditorState, onBack: () -> Unit) {
    val context = LocalContext.current
    val uiState = rememberGamepadUiState()

    var showMapping by remember { mutableStateOf(false) }
    var isOverlayRunning by remember { mutableStateOf(false) }

    // Day 4 "handle touch cancel correctly" safety net: if this screen is
    // ever removed from composition mid-press (back navigation, process
    // death, whatever) while a finger is still down, nothing is left
    // stuck highlighted the next time the screen appears, because there
    // simply is no next time for this particular uiState instance — a
    // fresh one is created when the screen is re-entered. This also
    // covers the pathological case of a gesture callback firing just as
    // the screen is leaving.
    DisposableEffect(uiState) {
        onDispose { uiState.clearAllPressed() }
    }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (OverlayPermission.isGranted(context)) {
            context.startService(Intent(context, GamepadOverlayService::class.java))
            isOverlayRunning = true
        } else {
            Toast.makeText(context, "Overlay permission was not granted", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleOverlay() {
        if (isOverlayRunning) {
            context.stopService(Intent(context, GamepadOverlayService::class.java))
            isOverlayRunning = false
        } else if (OverlayPermission.isGranted(context)) {
            context.startService(Intent(context, GamepadOverlayService::class.java))
            isOverlayRunning = true
        } else {
            overlayPermissionLauncher.launch(OverlayPermission.requestIntent(context))
        }
    }

    // Back navigation is layered: close the mapping panel first if it's
    // open, then exit Edit Mode if that's on, and only then leave the screen.
    BackHandler {
        when {
            showMapping -> showMapping = false
            editor.isEditMode -> editor.setEditMode(false)
            else -> onBack()
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val shorterSide = if (maxWidth < maxHeight) maxWidth else maxHeight

        val stickDiameter = (shorterSide * 0.40f).coerceIn(120.dp, 180.dp)
        val dPadSize = (shorterSide * 0.30f).coerceIn(84.dp, 130.dp)
        val actionSize = (shorterSide * 0.34f).coerceIn(110.dp, 165.dp)
        val sidePadding = if (maxWidth > 700.dp) 36.dp else 16.dp

        // ---- Top edge: utility icon · Keyboard · status/edit/overlay toggles · Nova mark ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = sidePadding, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            UtilityIconButton(onClick = onBack)
            KeyboardIndicator()
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusToggleButton(
                    isStatusVisible = uiState.statusVisible,
                    onToggle = { uiState.toggleStatusOverlay() }
                )
                EditModeToggleButton(
                    isEditMode = editor.isEditMode,
                    onToggle = { editor.setEditMode(!editor.isEditMode) }
                )
                OverlayToggleButton(
                    isOverlayRunning = isOverlayRunning,
                    onToggle = { toggleOverlay() }
                )
                NovaHexMark()
            }
        }

        // ---- Shoulder clusters, tilted, fanning out from the top corners ----
        ShoulderCluster(
            outerControl = GamepadControl.SHOULDER_LT,
            outerElement = LayoutElement.SHOULDER_LT,
            innerControl = GamepadControl.SHOULDER_LB,
            innerElement = LayoutElement.SHOULDER_LB,
            uiState = uiState,
            editor = editor,
            mirrored = false,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 4.dp, top = 46.dp)
        )
        ShoulderCluster(
            outerControl = GamepadControl.SHOULDER_RT,
            outerElement = LayoutElement.SHOULDER_RT,
            innerControl = GamepadControl.SHOULDER_RB,
            innerElement = LayoutElement.SHOULDER_RB,
            uiState = uiState,
            editor = editor,
            mirrored = true,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 4.dp, top = 46.dp)
        )

        // ---- Bottom: left joystick+D-pad <-> Back/Home/Start <-> right joystick+diamond ----
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = sidePadding, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                EditableElement(LayoutElement.LEFT_JOYSTICK, editor) {
                    Joystick(
                        diameter = stickDiameter,
                        control = GamepadControl.JOYSTICK_LEFT,
                        uiState = uiState,
                        sensitivity = editor.leftStickSettings.sensitivity,
                        deadZone = editor.leftStickSettings.deadzone
                    )
                }
                EditableElement(LayoutElement.DPAD, editor, Modifier.padding(start = 20.dp)) {
                    DPad(size = dPadSize, uiState = uiState)
                }
            }

            SystemButtonsRow(
                uiState = uiState,
                modifier = Modifier.padding(bottom = 44.dp)
            )

            Row(verticalAlignment = Alignment.Bottom) {
                EditableElement(LayoutElement.RIGHT_JOYSTICK, editor) {
                    Joystick(
                        diameter = stickDiameter,
                        control = GamepadControl.JOYSTICK_RIGHT,
                        uiState = uiState,
                        centerLabel = "R",
                        sensitivity = editor.rightStickSettings.sensitivity,
                        deadZone = editor.rightStickSettings.deadzone
                    )
                }
                ActionButtons(
                    size = actionSize,
                    uiState = uiState,
                    editor = editor,
                    modifier = Modifier.padding(start = 20.dp)
                )
            }
        }

        if (uiState.statusVisible) {
            StatusOverlay(
                uiState = uiState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp)
            )
        }

        // ---- Edit Mode UI: toolbar always shown while editing, element panel while something's selected ----
        if (editor.isEditMode) {
            EditModeToolbar(
                onMapping = { showMapping = true },
                onSave = {
                    val saved = ControllerLayoutStorage.save(context, editor.toConfig())
                    Toast.makeText(
                        context,
                        if (saved) "Layout saved" else "Couldn't save layout",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                onReset = {
                    editor.resetLayout()
                    Toast.makeText(context, "Layout reset to default", Toast.LENGTH_SHORT).show()
                },
                onDone = { editor.setEditMode(false) },
                modifier = Modifier.align(Alignment.Center)
            )

            editor.selectedElement?.let { selected ->
                EditPanel(
                    element = selected,
                    editor = editor,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(top = 64.dp)
                )
            }
        }

        if (showMapping) {
            KeyMappingPanel(
                editor = editor,
                onClose = { showMapping = false },
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}
