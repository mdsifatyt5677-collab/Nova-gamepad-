package com.novagamepad.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaOrangeSoft
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaSurfaceOutline
import com.novagamepad.app.ui.theme.NovaTextSecondary
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Large centered "Add Game" entry point. Sized explicitly by the caller
 * (rather than a width fraction) so it stays well-proportioned in the
 * short, wide landscape frame the app runs in. For Day 1 this only reports
 * the click upward; Day 2 will point this at the real game-profile flow.
 */
@Composable
fun AddGameCard(
    onClick: () -> Unit,
    size: Dp,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier.size(size),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = NovaSurface),
        border = BorderStroke(1.dp, NovaSurfaceOutline),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(NovaOrangeSoft)
                    .border(1.5.dp, NovaOrange.copy(alpha = 0.55f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = null,
                    tint = NovaOrange,
                    modifier = Modifier.size(28.dp)
                )
            }

            Text(
                text = "Add Game",
                style = MaterialTheme.typography.titleMedium,
                color = NovaWhite,
                modifier = Modifier.padding(top = 14.dp)
            )
            Text(
                text = "Create a controller profile",
                style = MaterialTheme.typography.bodyMedium,
                color = NovaTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
