package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaOrangeSoft
import com.novagamepad.app.ui.theme.NovaSurfaceElevated
import com.novagamepad.app.ui.theme.NovaTextSecondary
import com.novagamepad.app.ui.theme.NovaWhite
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Large virtual analog joystick matching the reference: a thin-outlined,
 * dark/transparent base, small directional tick marks around the edge, and
 * a small dark knob (optionally carrying a center label, e.g. "R" for the
 * right stick).
 *
 * Behaves like a real controller's stick on two levels at once, exactly
 * like the physical hardware it mirrors:
 *  - **Analog**: the knob tracks the finger 1:1 within the base, is clamped
 *    so it can never leave the circle, and snaps back to center on release,
 *    reporting a normalized -1..1 x/y through [GamepadUiState.updateStick]
 *    — after [sensitivity] and [deadZone] are applied (Day 4's Joystick
 *    Settings). The knob's own on-screen position always follows the
 *    finger 1:1 regardless of these settings; only the *reported* value is
 *    adjusted, so the stick still feels physically natural to hold.
 *  - **Digital (L3/R3)**: on a real gamepad the stick is also a clickable
 *    button — you press straight down on it. A touchscreen can't sense that
 *    separate downward force, so touching the stick at all presses its
 *    click control ([GamepadControl.STICK_LEFT_CLICK] /
 *    [GamepadControl.STICK_RIGHT_CLICK]) for as long as contact holds, the
 *    same way holding L3 down while tilting the stick works on real
 *    hardware. The knob's border/fill highlights while that's active.
 *
 * Reset-on-release is wrapped in try/finally around the whole gesture
 * (not just the onDragEnd/onDragCancel callbacks) — the Day 4 fix so the
 * knob can never get stuck off-center if the drag gesture is torn down
 * abruptly rather than ending normally.
 *
 * [control] must be [GamepadControl.JOYSTICK_LEFT] or
 * [GamepadControl.JOYSTICK_RIGHT] — each stick, and its click, is fully
 * independent, so both can be dragged (and clicked) at the same time.
 */
@Composable
fun Joystick(
    diameter: Dp,
    control: GamepadControl,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier,
    centerLabel: String? = null,
    sensitivity: Float = 1f,
    deadZone: Float = 0.12f
) {
    val density = LocalDensity.current
    val knobFraction = 0.34f
    val radiusPx = with(density) { (diameter / 2).toPx() }
    val knobRadiusPx = with(density) { (diameter * knobFraction / 2).toPx() }
    val maxOffsetPx = radiusPx - knobRadiusPx

    val clickControl = remember(control) {
        when (control) {
            GamepadControl.JOYSTICK_LEFT -> GamepadControl.STICK_LEFT_CLICK
            GamepadControl.JOYSTICK_RIGHT -> GamepadControl.STICK_RIGHT_CLICK
            else -> control
        }
    }

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val isSelected = uiState.selected == control
    val isClicked = uiState.isPressed(clickControl)

    fun reportStick() {
        val rawX = offsetX / maxOffsetPx
        val rawY = -offsetY / maxOffsetPx // inverted so "up" on screen reports as positive
        val magnitude = sqrt(rawX * rawX + rawY * rawY)
        if (magnitude < deadZone) {
            uiState.updateStick(control, 0f, 0f)
        } else {
            val reportedX = (rawX * sensitivity).coerceIn(-1f, 1f)
            val reportedY = (rawY * sensitivity).coerceIn(-1f, 1f)
            uiState.updateStick(control, reportedX, reportedY)
        }
    }

    fun resetKnob() {
        offsetX = 0f
        offsetY = 0f
        uiState.updateStick(control, 0f, 0f)
        uiState.release(clickControl)
    }

    Box(
        modifier = modifier
            .size(diameter)
            .clip(CircleShape)
            .background(Color.Transparent)
            .border(
                width = if (isSelected) 2.dp else 1.5.dp,
                color = if (isSelected) NovaOrange else NovaControllerOutline,
                shape = CircleShape
            )
            .pointerInput(control, sensitivity, deadZone) {
                try {
                    detectDragGestures(
                        onDragStart = {
                            uiState.press(clickControl)
                            reportStick()
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val newX = offsetX + dragAmount.x
                            val newY = offsetY + dragAmount.y
                            val distance = sqrt(newX * newX + newY * newY)
                            if (distance > maxOffsetPx && distance > 0f) {
                                val scale = maxOffsetPx / distance
                                offsetX = newX * scale
                                offsetY = newY * scale
                            } else {
                                offsetX = newX
                                offsetY = newY
                            }
                            reportStick()
                        },
                        onDragEnd = { resetKnob() },
                        onDragCancel = { resetKnob() }
                    )
                } finally {
                    // Same belt-and-suspenders guarantee as GamepadButton: if this
                    // coroutine is torn down some other way, the stick still snaps
                    // back to center and its click releases instead of staying stuck.
                    resetKnob()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        // Small directional tick marks around the edge — decorative only,
        // the drag gesture on the whole base handles actual direction.
        Icon(
            imageVector = Icons.Filled.KeyboardArrowUp,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.TopCenter).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.BottomCenter).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowLeft,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.CenterStart).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.CenterEnd).size(16.dp)
        )

        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(diameter * knobFraction)
                .clip(CircleShape)
                .background(if (isClicked) NovaOrangeSoft else NovaSurfaceElevated)
                .border(
                    width = if (isClicked) 2.dp else 1.dp,
                    color = if (isClicked) NovaOrange else NovaControllerOutline,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (centerLabel != null) {
                Text(
                    text = centerLabel,
                    color = NovaWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
