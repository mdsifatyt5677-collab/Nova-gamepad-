package com.novagamepad.app.data.model

/**
 * A controller element's customization: how far it's been dragged from
 * its Day 2 default position, how big it is, and how opaque. Plain data
 * (no Compose types) so it's trivial to store as JSON — see
 * [com.novagamepad.app.data.storage.ControllerLayoutStorage].
 */
data class ControlTransform(
    val offsetXDp: Float = 0f,
    val offsetYDp: Float = 0f,
    val scale: Float = 1f,
    val opacity: Float = 1f,
    val isVisible: Boolean = true
)
