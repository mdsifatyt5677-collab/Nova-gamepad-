package com.novagamepad.app.features.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaBackground
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaWhite
import kotlin.math.roundToInt

/**
 * What actually renders inside the floating overlay window.
 *
 * Deliberately a small draggable bubble, not the full editable controller.
 * That's a scope decision, not an oversight: this proves the whole
 * permission -> service -> WindowManager -> Compose pipeline genuinely
 * works end to end, without the much larger risk of running the entire
 * controller (with all its gesture handling) inside a system overlay
 * window that I have no way to test on a real device from here. Growing
 * this into the full floating controller is the natural next step once
 * this foundation has been verified on an actual phone.
 *
 * IMPORTANT: dragging this bubble moves the window. Nothing it does sends
 * input to whatever app is underneath — that would require an
 * Accessibility Service, Shizuku, or root, none of which this project
 * uses. See [GamepadOverlayService]'s doc comment for the full picture.
 */
@Composable
fun OverlayContent(onStop: () -> Unit) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Row(
        modifier = Modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .clip(RoundedCornerShape(50))
            .background(NovaBackground)
            .border(1.dp, NovaOrange, RoundedCornerShape(50))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Nova Gamepad", color = NovaWhite, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = "Stop",
            color = NovaOrange,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .padding(start = 12.dp)
                .clip(RoundedCornerShape(50))
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { onStop() })
                }
        )
    }
}
