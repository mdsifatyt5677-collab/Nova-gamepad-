package com.novagamepad.app.data.model

import com.novagamepad.app.features.gamepad.model.GamepadControl

/**
 * Everything Save/Load persists: each element's position/size/opacity,
 * and each button's assigned key label. An empty [transforms] map means
 * "use the Day 2 default layout" — see [LayoutElement] and
 * [com.novagamepad.app.features.gamepad.model.EditorState].
 */
data class ControllerLayoutConfig(
    val transforms: Map<LayoutElement, ControlTransform> = emptyMap(),
    val mappings: Map<GamepadControl, String> = emptyMap(),
    val globalScale: Float = 1f,
    val globalOpacity: Float = 1f,
    val leftStickSettings: JoystickSettings = JoystickSettings(),
    val rightStickSettings: JoystickSettings = JoystickSettings()
)
