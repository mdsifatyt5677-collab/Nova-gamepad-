package com.novagamepad.app.ui.screens.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.data.storage.ControllerLayoutStorage
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.ui.theme.NovaBackground
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaSurfaceOutline
import com.novagamepad.app.ui.theme.NovaTextSecondary
import com.novagamepad.app.ui.theme.NovaWhite
import java.util.Locale

/**
 * Reached from the Home Screen's Settings icon (Day 4). Holds every
 * "Controller Settings panel" control that doesn't require seeing the
 * live controller — joystick sensitivity/dead-zone (separately per
 * stick), global button size/opacity, per-element show/hide, and
 * Save/Reset — plus a button that jumps straight into the on-controller
 * editor (drag/resize/key-mapping) for the controls that genuinely need
 * to be seen to be edited.
 *
 * Operates on the same [EditorState] instance the Gamepad Preview screen
 * uses (created once in MainActivity), so a slider dragged here is live
 * on the controller immediately, and nothing gets lost switching between
 * the two screens.
 */
@Composable
fun ControllerSettingsScreen(
    editor: EditorState,
    onBack: () -> Unit,
    onOpenEditor: () -> Unit
) {
    val context = LocalContext.current

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val contentWidth = (maxWidth * 0.7f).coerceIn(320.dp, 560.dp)

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NovaWhite)
                }
                Text(
                    text = "Controller Settings",
                    color = NovaWhite,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SettingsButton(
                    label = "Open Controller Editor",
                    onClick = {
                        editor.setEditMode(true)
                        onOpenEditor()
                    },
                    modifier = Modifier
                        .width(contentWidth)
                        .padding(bottom = 16.dp)
                )

                SettingsSection("Joystick Sensitivity", contentWidth) {
                    LabeledSlider(
                        label = "Left",
                        value = editor.leftStickSettings.sensitivity,
                        valueRange = 0.3f..2f,
                        onValueChange = { editor.setLeftStickSensitivity(it) }
                    )
                    LabeledSlider(
                        label = "Right",
                        value = editor.rightStickSettings.sensitivity,
                        valueRange = 0.3f..2f,
                        onValueChange = { editor.setRightStickSensitivity(it) }
                    )
                }

                SettingsSection("Joystick Dead Zone", contentWidth) {
                    LabeledSlider(
                        label = "Left",
                        value = editor.leftStickSettings.deadzone,
                        valueRange = 0f..0.5f,
                        onValueChange = { editor.setLeftStickDeadzone(it) }
                    )
                    LabeledSlider(
                        label = "Right",
                        value = editor.rightStickSettings.deadzone,
                        valueRange = 0f..0.5f,
                        onValueChange = { editor.setRightStickDeadzone(it) }
                    )
                }

                SettingsSection("Button Size", contentWidth) {
                    LabeledSlider(
                        label = "All buttons",
                        value = editor.globalScale,
                        valueRange = 0.6f..1.6f,
                        onValueChange = { editor.setGlobalScale(it) }
                    )
                }

                SettingsSection("Button Opacity", contentWidth) {
                    LabeledSlider(
                        label = "All buttons",
                        value = editor.globalOpacity,
                        valueRange = 0.3f..1f,
                        onValueChange = { editor.setGlobalOpacity(it) }
                    )
                }

                SettingsSection("Show / Hide Controls", contentWidth) {
                    for (element in LayoutElement.values()) {
                        VisibilityRow(
                            label = element.displayName,
                            visible = editor.isVisible(element),
                            onToggle = { editor.toggleVisible(element) }
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .width(contentWidth)
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SettingsButton(
                        label = "Save Layout",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val saved = ControllerLayoutStorage.save(context, editor.toConfig())
                            Toast.makeText(
                                context,
                                if (saved) "Layout saved" else "Couldn't save layout",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    )
                    SettingsButton(
                        label = "Reset Layout",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            editor.resetLayout()
                            Toast.makeText(context, "Layout reset to default", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, width: Dp, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .width(width)
            .padding(bottom = 16.dp)
    ) {
        Text(title, color = NovaTextSecondary, style = MaterialTheme.typography.bodyMedium)
        Spacer(modifier = Modifier.height(4.dp))
        content()
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = NovaWhite, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = String.format(Locale.US, "%.2f", value),
                color = NovaTextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = NovaOrange,
                activeTrackColor = NovaOrange,
                inactiveTrackColor = NovaSurfaceOutline
            )
        )
    }
}

@Composable
private fun VisibilityRow(label: String, visible: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = NovaWhite, style = MaterialTheme.typography.bodyMedium)
        Switch(
            checked = visible,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = NovaOrange,
                checkedTrackColor = NovaOrange.copy(alpha = 0.4f),
                uncheckedThumbColor = NovaTextSecondary,
                uncheckedTrackColor = NovaSurfaceOutline
            )
        )
    }
}

@Composable
private fun SettingsButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(NovaSurface)
            .border(1.dp, NovaOrange, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = NovaOrange,
            style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center
        )
    }
}
