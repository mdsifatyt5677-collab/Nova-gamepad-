package com.novagamepad.app.features.gamepad.model

/**
 * Stable identifier for every touchable element on the gamepad preview.
 * Used for press/selection state today; Day 3's key-mapping and layout
 * editor will key their data off the same enum instead of raw strings.
 *
 * Mirrors a standard controller's button set: face buttons, D-pad,
 * shoulder buttons/triggers, clickable sticks (L3/R3), and the system
 * row (Back/View, Guide/Home, Start/Menu).
 */
enum class GamepadControl(val label: String) {
    ACTION_A("A"),
    ACTION_B("B"),
    ACTION_X("X"),
    ACTION_Y("Y"),
    DPAD_UP("Up"),
    DPAD_DOWN("Down"),
    DPAD_LEFT("Left"),
    DPAD_RIGHT("Right"),
    SHOULDER_LB("LB"),
    SHOULDER_LT("LT"),
    SHOULDER_RB("RB"),
    SHOULDER_RT("RT"),
    /** Clicking the left analog stick itself — not a separate button, see [Joystick]. */
    STICK_LEFT_CLICK("LS"),
    /** Clicking the right analog stick itself — not a separate button, see [Joystick]. */
    STICK_RIGHT_CLICK("RS"),
    JOYSTICK_LEFT("Left Joystick"),
    JOYSTICK_RIGHT("Right Joystick"),
    BACK_SELECT("Back"),
    GUIDE_HOME("Home"),
    START("Start");

    companion object {
        /**
         * Every control that makes sense to bind to a single keyboard key.
         * The two analog sticks are deliberately excluded — they report a
         * continuous X/Y, not a single press, so they aren't in scope for
         * Day 3's "one button → one key" mapping model.
         */
        val mappable: List<GamepadControl> = listOf(
            ACTION_A, ACTION_B, ACTION_X, ACTION_Y,
            DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT,
            SHOULDER_LB, SHOULDER_LT, SHOULDER_RB, SHOULDER_RT,
            STICK_LEFT_CLICK, STICK_RIGHT_CLICK,
            BACK_SELECT, GUIDE_HOME, START
        )
    }
}
