package com.novagamepad.app.ui.screens.home

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.components.AddGameCard
import com.novagamepad.app.ui.components.AppHeader
import com.novagamepad.app.ui.components.PreviewButton
import com.novagamepad.app.ui.theme.NovaBackground
import kotlinx.coroutines.launch

/**
 * Day 1 Home Screen.
 *
 * The app runs locked to landscape, so this layout is tuned for a short,
 * wide frame: a slim header, a card centered in the remaining space and
 * sized from the *shorter* screen dimension (so it never overflows
 * vertically on small phones), and a fixed-width pill button anchored to
 * the bottom instead of stretching edge to edge.
 */
@Composable
fun HomeScreen(
    onAddGameClick: () -> Unit = {},
    onPreviewClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {}
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun showPlaceholder(message: String) {
        scope.launch { snackbarHostState.showSnackbar(message) }
    }

    Scaffold(
        containerColor = NovaBackground,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(snackbarData = data)
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val shorterSide = if (maxWidth < maxHeight) maxWidth else maxHeight
            val cardSize = (shorterSide * 0.62f).coerceIn(150.dp, 260.dp)
            val sidePadding = if (maxWidth > 700.dp) 56.dp else 24.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = sidePadding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppHeader(
                    onSettingsClick = onSettingsClick,
                    modifier = Modifier.padding(horizontal = 0.dp)
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    AddGameCard(
                        size = cardSize,
                        onClick = {
                            showPlaceholder("Game profiles are coming soon")
                            onAddGameClick()
                        }
                    )
                }

                PreviewButton(
                    onClick = onPreviewClick,
                    modifier = Modifier.padding(bottom = 18.dp)
                )
            }
        }
    }
}
