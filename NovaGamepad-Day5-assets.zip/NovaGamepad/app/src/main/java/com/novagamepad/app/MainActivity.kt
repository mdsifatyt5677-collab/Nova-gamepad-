package com.novagamepad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.novagamepad.app.data.storage.ControllerLayoutStorage
import com.novagamepad.app.features.gamepad.GamepadPreviewScreen
import com.novagamepad.app.features.gamepad.model.rememberEditorState
import com.novagamepad.app.ui.screens.home.HomeScreen
import com.novagamepad.app.ui.screens.settings.ControllerSettingsScreen
import com.novagamepad.app.ui.theme.NovaGamepadTheme

/** The app's three destinations as of Day 4. */
private enum class NovaScreen { Home, GamepadPreview, Settings }

/**
 * Single-activity entry point. Screen switching is a plain in-memory state
 * flag rather than a navigation library — with only three destinations,
 * Navigation-Compose would be unused weight.
 *
 * The controller's [com.novagamepad.app.features.gamepad.model.EditorState]
 * is created *here*, once, and passed down to both the Settings screen and
 * the Gamepad Preview screen — not created separately inside each — so a
 * change made in Settings (say, dragging the sensitivity slider) is
 * immediately live on the controller, and "Open Controller Editor" always
 * lands on exactly the state you left it in. The saved layout is loaded
 * from disk once here at startup rather than every time Preview is
 * entered, since this single shared instance carries forward for the rest
 * of the app session regardless of which screen is showing.
 *
 * The window is also put into true immersive fullscreen here (status bar
 * and navigation bar hidden, content drawn edge-to-edge) automatically on
 * every device — there is no phone/tablet mode to pick, the same code
 * adapts to whatever screen it runs on.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()

        setContent {
            NovaGamepadTheme {
                var screen by remember { mutableStateOf(NovaScreen.Home) }
                val editor = rememberEditorState()
                val context = LocalContext.current

                // Loads once per app session. A missing or unreadable save
                // just means "use the Day 2 defaults" — ControllerLayoutStorage
                // already returns null in that case, which EditorState is
                // fine with (it just means no customization yet).
                LaunchedEffect(Unit) {
                    ControllerLayoutStorage.load(context)?.let { editor.loadFrom(it) }
                }

                when (screen) {
                    NovaScreen.Home -> HomeScreen(
                        onPreviewClick = { screen = NovaScreen.GamepadPreview },
                        onSettingsClick = { screen = NovaScreen.Settings }
                    )
                    NovaScreen.GamepadPreview -> GamepadPreviewScreen(
                        editor = editor,
                        onBack = { screen = NovaScreen.Home }
                    )
                    NovaScreen.Settings -> ControllerSettingsScreen(
                        editor = editor,
                        onBack = { screen = NovaScreen.Home },
                        onOpenEditor = { screen = NovaScreen.GamepadPreview }
                    )
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BY_SWIPE_GESTURE
    }
}
