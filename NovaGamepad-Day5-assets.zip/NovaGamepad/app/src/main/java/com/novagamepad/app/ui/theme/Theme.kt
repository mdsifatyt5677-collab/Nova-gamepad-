package com.novagamepad.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// Nova Gamepad is a dark-first tool used over games, so it always renders in
// the dark scheme regardless of system setting. Kept as its own function so
// Day 2/3 screens (profile editor, controller layout, settings) share it.
private val NovaColorScheme = darkColorScheme(
    background = NovaBackground,
    surface = NovaSurface,
    primary = NovaOrange,
    onPrimary = NovaBackground,
    onBackground = NovaWhite,
    onSurface = NovaWhite,
    outline = NovaSurfaceOutline,
    secondary = NovaTextSecondary
)

@Composable
fun NovaGamepadTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NovaColorScheme,
        typography = NovaTypography,
        content = content
    )
}
