package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaOrangeSoft
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Single reusable control surface used for every button on the gamepad
 * preview — action buttons, D-pad arrows, shoulder buttons. Styled
 * to match the reference layout: transparent/dark interior with a thin
 * light outline at rest. Orange is used only as brief interaction
 * feedback (a subtle tint + brighter border while pressed, a thin border
 * while selected) — never as a large filled background.
 *
 * Press state lives in [GamepadUiState.pressed] as a *set*, so every
 * button and both stick-clicks are fully independent — multi-touch just
 * works, pressing one never disturbs another already held down. Release
 * is guaranteed via try/finally around the gesture, even if it's
 * cancelled rather than released normally (Day 4 fix for the
 * stuck-highlight bug).
 */
@Composable
fun GamepadButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    content: @Composable () -> Unit
) {
    val isPressed = uiState.isPressed(control)
    val isSelected = uiState.selected == control

    val borderColor = if (isPressed || isSelected) NovaOrange else NovaControllerOutline
    val borderWidth = if (isPressed) 2.dp else 1.5.dp
    val backgroundColor = if (isPressed) NovaOrangeSoft else Color.Transparent

    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(width = borderWidth, color = borderColor, shape = shape)
            .pointerInput(control) {
                try {
                    detectTapGestures(
                        onPress = {
                            uiState.press(control)
                            try {
                                tryAwaitRelease()
                            } finally {
                                // Runs on a normal release AND on cancellation (e.g. the
                                // gesture gets consumed elsewhere, or this composable
                                // leaves composition mid-press) — the Day 4 fix for
                                // buttons getting stuck highlighted.
                                uiState.release(control)
                            }
                        }
                    )
                } finally {
                    // Belt-and-suspenders: if the whole pointerInput coroutine itself
                    // is torn down (key change, removal from the tree) before onPress
                    // even got a chance to run its own finally, this still guarantees
                    // the control isn't left marked pressed.
                    uiState.release(control)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides NovaWhite) {
            content()
        }
    }
}
