package com.novagamepad.app.data.model

/**
 * Per-joystick tuning: [sensitivity] scales the reported output (values
 * above 1 reach full deflection before the finger physically reaches the
 * edge of the stick's travel; values below 1 need more physical movement
 * to reach the same output), and [deadzone] is the normalized radius
 * around center that's reported as exactly zero, to absorb small
 * accidental touches/drift. Left and right sticks each get their own
 * instance so one can be tuned without affecting the other.
 */
data class JoystickSettings(
    val sensitivity: Float = 1f,
    val deadzone: Float = 0.12f
)
