package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Lets the user assign a keyboard key label to each mappable button —
 * "A → Space", "B → E", and so on. This is configuration only: it stores
 * the mapping in [EditorState] (and, on Save, to disk). Nothing here
 * injects that key into any other app — see the note in
 * [com.novagamepad.app.features.gamepad.GamepadPreviewScreen].
 */
@Composable
fun KeyMappingPanel(
    editor: EditorState,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(NovaSurface)
            .border(1.dp, NovaControllerOutline, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Key Mapping", color = NovaWhite, style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose, modifier = Modifier.size(26.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = NovaWhite, modifier = Modifier.size(16.dp))
            }
        }

        LazyColumn(modifier = Modifier.height(230.dp)) {
            items(GamepadControl.mappable) { control ->
                MappingRow(control = control, editor = editor)
            }
        }
    }
}

/** Also used by [EditPanel]'s "Set Key" section for the selected element's own control(s). */
@Composable
fun MappingRow(control: GamepadControl, editor: EditorState) {
    var text by remember(control) { mutableStateOf(editor.mappings[control] ?: "") }

    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = control.label,
            color = NovaWhite,
            modifier = Modifier.width(56.dp)
        )
        OutlinedTextField(
            value = text,
            onValueChange = { newValue ->
                val trimmed = newValue.take(12)
                text = trimmed
                editor.setMapping(control, trimmed)
            },
            singleLine = true,
            placeholder = { Text("unmapped") },
            modifier = Modifier.width(150.dp)
        )
    }
}
