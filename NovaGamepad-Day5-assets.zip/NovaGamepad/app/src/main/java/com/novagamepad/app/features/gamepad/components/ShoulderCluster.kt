package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * A shoulder-button pair (outer above/outside, inner below/inside), tilted
 * at an angle the way they sit in the reference image — instead of a
 * plain horizontal row. [mirrored] flips the whole cluster for the right
 * side (RT/RB), so the two sides fan outward symmetrically.
 *
 * Each button is its own [EditableElement]: the Day 3 spec lists
 * LT/LB/RT/RB as individually movable, unlike the D-pad or a joystick
 * which move as one unit.
 */
@Composable
fun ShoulderCluster(
    outerControl: GamepadControl,
    outerElement: LayoutElement,
    innerControl: GamepadControl,
    innerElement: LayoutElement,
    uiState: GamepadUiState,
    editor: EditorState,
    mirrored: Boolean,
    modifier: Modifier = Modifier
) {
    val sign = if (mirrored) -1f else 1f
    val corner = RoundedCornerShape(22.dp)
    val buttonWidth = 84.dp
    val buttonHeight = 72.dp
    val alignment = if (mirrored) Alignment.TopEnd else Alignment.TopStart

    Box(modifier = modifier.size(150.dp, 150.dp)) {
        EditableElement(
            element = outerElement,
            editor = editor,
            modifier = Modifier
                .align(alignment)
                .offset(x = 4.dp * sign, y = 4.dp)
        ) {
            ShoulderButton(outerControl, uiState, corner, buttonWidth, buttonHeight, sign * -22f)
        }
        EditableElement(
            element = innerElement,
            editor = editor,
            modifier = Modifier
                .align(alignment)
                .offset(x = 42.dp * sign, y = 62.dp)
        ) {
            ShoulderButton(innerControl, uiState, corner, buttonWidth, buttonHeight, sign * 20f)
        }
    }
}

@Composable
private fun ShoulderButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    shape: RoundedCornerShape,
    width: Dp,
    height: Dp,
    rotationDegrees: Float
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = shape,
        modifier = Modifier
            .size(width = width, height = height)
            .rotate(rotationDegrees)
    ) {
        Text(
            text = control.label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
        )
    }
}
