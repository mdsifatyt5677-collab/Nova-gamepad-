package com.novagamepad.app.features.settings

// The real Settings screen (reached from the header icon) will live here.
// Intentionally empty on Day 1 — see PROJECT sprint plan.
// This package exists so the module boundary is in place before
// implementation starts, keeping later work additive rather than a rewrite.
