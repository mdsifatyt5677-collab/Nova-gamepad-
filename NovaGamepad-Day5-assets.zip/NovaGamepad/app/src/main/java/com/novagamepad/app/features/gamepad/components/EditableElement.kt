package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.ui.theme.NovaBackground
import com.novagamepad.app.ui.theme.NovaOrange

/**
 * Wraps any controller element (a joystick, the D-pad, an action button...)
 * to make it repositionable, resizable, adjustable in opacity, and
 * hideable — the Day 3/4 customization layer.
 *
 * In Play mode this is a total no-op for a *visible* element: no extra
 * modifiers beyond applying the element's saved transform, no gesture
 * handling at all — the wrapped [content] behaves exactly as it did on
 * Day 2. A *hidden* element (Day 4's per-control visibility toggle) is
 * simply not composed at all in Play mode, so it can't be seen or
 * accidentally touched.
 *
 * In Edit mode, a transparent layer is drawn *on top* of [content] that
 * captures touches there instead: a tap selects the element (shown with an
 * orange outline), a drag moves it. Because that capture layer is a later
 * sibling — drawn on top, hit-tested first — and consumes the touches it
 * handles, the real button/joystick underneath never sees them, so editing
 * can't accidentally trigger a press. A hidden element still renders here
 * (dimmed, with a small "hidden" badge) so it can be selected and
 * re-enabled from the panel instead of vanishing entirely from the editor.
 */
@Composable
fun EditableElement(
    element: LayoutElement,
    editor: EditorState,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val transform = editor.transformOf(element)
    val isSelected = editor.isEditMode && editor.selectedElement == element
    val isVisible = editor.isVisible(element)

    if (!editor.isEditMode && !isVisible) {
        return
    }

    val effectiveScale = transform.scale * editor.globalScale
    val effectiveOpacity = if (!isVisible) 0.3f else (transform.opacity * editor.globalOpacity)

    Box(
        modifier = modifier.offset(x = transform.offsetXDp.dp, y = transform.offsetYDp.dp)
    ) {
        Box(
            modifier = Modifier.graphicsLayer(
                scaleX = effectiveScale,
                scaleY = effectiveScale,
                alpha = effectiveOpacity
            )
        ) {
            content()
        }

        if (editor.isEditMode) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) NovaOrange else NovaOrange.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .pointerInput(element) {
                        detectTapGestures(onPress = { editor.selectElement(element) })
                    }
                    .pointerInput(element) {
                        detectDragGestures(
                            onDragStart = { editor.selectElement(element) },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                editor.nudgeOffset(element, dragAmount.x.toDp(), dragAmount.y.toDp())
                            }
                        )
                    }
            )

            if (!isVisible) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(CircleShape)
                        .background(NovaBackground.copy(alpha = 0.75f))
                        .border(1.dp, NovaOrange, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Filled.VisibilityOff,
                        contentDescription = "Hidden in Play Mode",
                        tint = NovaOrange,
                        modifier = Modifier.padding(4.dp).size(14.dp)
                    )
                }
            }
        }
    }
}
