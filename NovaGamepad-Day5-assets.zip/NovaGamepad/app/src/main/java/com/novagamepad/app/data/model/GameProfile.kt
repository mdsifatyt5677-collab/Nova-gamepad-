package com.novagamepad.app.data.model

/**
 * Shape of a saved game profile: which app it's for, and (eventually) which
 * gamepad layout to overlay on top of it.
 *
 * Not wired into any UI yet — this exists so Day 2's "Add Game" flow and
 * profile list have a model to build against from the start, instead of
 * bolting one on later.
 */
data class GameProfile(
    val id: String,
    val displayName: String,
    val packageName: String? = null,
    val layoutId: String? = null
)
