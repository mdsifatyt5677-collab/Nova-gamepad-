package com.novagamepad.app.data.repository

import com.novagamepad.app.data.model.GameProfile

/**
 * Placeholder repository contract for game profiles. Day 2 fills in a real
 * implementation (likely backed by local storage). Kept as an interface so
 * the UI layer can be built against it before the storage decision is made.
 */
interface GameProfileRepository {
    suspend fun getProfiles(): List<GameProfile>
    suspend fun saveProfile(profile: GameProfile)
    suspend fun deleteProfile(id: String)
}
