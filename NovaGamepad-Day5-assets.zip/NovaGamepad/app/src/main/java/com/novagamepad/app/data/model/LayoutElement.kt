package com.novagamepad.app.data.model

/**
 * Every controller element the Day 3 editor can select, move, resize, and
 * fade. Intentionally one level coarser than every touchable control:
 * the D-pad and each joystick move as a single unit (matching the Day 2
 * reference), while the four action buttons are individually placeable
 * since the reference treats them that way too.
 *
 * LS/RS aren't listed here — per the Day 2 "make it work like a real
 * controller" pass, they aren't separate visual elements, they're the
 * left/right stick's own click. They still get their own key-mapping
 * entries (see GamepadControl.mappable) — just not their own position.
 */
enum class LayoutElement(val displayName: String) {
    LEFT_JOYSTICK("Left Joystick"),
    RIGHT_JOYSTICK("Right Joystick"),
    DPAD("D-Pad"),
    ACTION_A("A"),
    ACTION_B("B"),
    ACTION_X("X"),
    ACTION_Y("Y"),
    SHOULDER_LT("LT"),
    SHOULDER_LB("LB"),
    SHOULDER_RT("RT"),
    SHOULDER_RB("RB")
}
