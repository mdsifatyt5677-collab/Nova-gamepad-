package com.novagamepad.app.features.gamepad.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateSetOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/**
 * Local, in-memory state for the gamepad preview: which controls are
 * currently pressed, each stick's normalized -1..1 offset, which element
 * is "selected" (subtle selection border), and whether the debug status
 * box is currently visible.
 *
 * [pressedControls] is a *set*, not a single value — this is the Day 4 fix
 * for the button-highlight bug. With a single nullable "pressed" value,
 * pressing button B while still holding button A would overwrite it,
 * making A's highlight incorrectly disappear even though it was still
 * physically held. A set lets every button (and each stick's click) track
 * its own press state completely independently, which is what makes
 * multi-touch actually work correctly.
 */
class GamepadUiState {
    private val pressedControls = mutableStateSetOf<GamepadControl>()

    /** Read-only view of every control currently pressed — may be more than one at once. */
    val pressed: Set<GamepadControl> get() = pressedControls

    var selected by mutableStateOf<GamepadControl?>(null)
        private set

    var leftStickX by mutableFloatStateOf(0f)
        private set

    var leftStickY by mutableFloatStateOf(0f)
        private set

    var rightStickX by mutableFloatStateOf(0f)
        private set

    var rightStickY by mutableFloatStateOf(0f)
        private set

    /** Whether the "Pressed: / Joystick:" debug readout is showing. */
    var statusVisible by mutableStateOf(true)
        private set

    fun isPressed(control: GamepadControl): Boolean = control in pressedControls

    fun press(control: GamepadControl) {
        pressedControls.add(control)
        selected = control
    }

    fun release(control: GamepadControl) {
        pressedControls.remove(control)
    }

    /**
     * Safety net for "handle touch cancel correctly": if the screen is
     * navigated away from (or the app is backgrounded) mid-press, this
     * clears every held button so nothing can ever get visually stuck in
     * a pressed state. See the DisposableEffect in GamepadPreviewScreen.
     */
    fun clearAllPressed() {
        pressedControls.clear()
    }

    /** Called by a [com.novagamepad.app.features.gamepad.components.Joystick] while it's being dragged. */
    fun updateStick(control: GamepadControl, x: Float, y: Float) {
        when (control) {
            GamepadControl.JOYSTICK_LEFT -> {
                leftStickX = x
                leftStickY = y
            }
            GamepadControl.JOYSTICK_RIGHT -> {
                rightStickX = x
                rightStickY = y
            }
            else -> Unit
        }
        if (x != 0f || y != 0f) {
            selected = control
        }
    }

    /** Toggled by the top-right three-line button to hide/show the debug status box. */
    fun toggleStatusOverlay() {
        statusVisible = !statusVisible
    }
}

@Composable
fun rememberGamepadUiState(): GamepadUiState = remember { GamepadUiState() }
