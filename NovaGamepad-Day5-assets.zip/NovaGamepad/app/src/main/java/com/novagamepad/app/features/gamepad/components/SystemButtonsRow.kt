package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * The three "system" buttons every standard controller has alongside the
 * main input cluster: Back/View, Guide/Home, and Start/Menu. Small,
 * circular, and outlined — same visual language as every other control.
 */
@Composable
fun SystemButtonsRow(
    uiState: GamepadUiState,
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        SystemIconButton(GamepadControl.BACK_SELECT, Icons.Outlined.Undo, uiState)
        SystemIconButton(GamepadControl.GUIDE_HOME, Icons.Outlined.Home, uiState)
        SystemIconButton(GamepadControl.START, Icons.Outlined.PlayArrow, uiState)
    }
}

@Composable
private fun SystemIconButton(
    control: GamepadControl,
    icon: ImageVector,
    uiState: GamepadUiState
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = CircleShape,
        modifier = Modifier.size(38.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = control.label,
            modifier = Modifier.size(18.dp)
        )
    }
}
