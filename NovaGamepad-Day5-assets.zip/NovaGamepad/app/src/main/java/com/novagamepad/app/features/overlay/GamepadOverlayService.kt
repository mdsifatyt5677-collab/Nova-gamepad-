package com.novagamepad.app.features.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.novagamepad.app.ui.theme.NovaGamepadTheme

/**
 * Shows Nova Gamepad as a system-level overlay window, floating above
 * other apps — the Day 3 "overlay-ready architecture" / "Overlay Test
 * Mode" requirement.
 *
 * WHAT THIS ACTUALLY DOES: draws [OverlayContent] on top of whatever app
 * is in the foreground, using the standard SYSTEM_ALERT_WINDOW permission.
 * You can drag it around and stop it. That's it.
 *
 * WHAT THIS DOES NOT DO: send input to the app underneath. A real game
 * controller overlay would need an Accessibility Service, Shizuku, or
 * root to inject that input system-wide — none of those are wired up
 * here, on purpose, per the Day 3 instruction not to fake input
 * injection. This service only proves the floating-window part of the
 * pipeline; the input-injection part is honestly out of scope for this
 * sandbox and is left as a clearly separate, future piece of work.
 *
 * SCOPE NOTE: this is a plain (non-foreground) Service, not a foreground
 * service with a persistent notification. Android 14's
 * foregroundServiceType rules are strict and version-specific in ways I
 * cannot verify without running this on a real device, and getting that
 * declaration wrong can crash the app outright. A plain Service is
 * simpler and has been stable for years; the tradeoff is Android may stop
 * it more eagerly if the app is fully backgrounded for a long time. For a
 * user-initiated "Start/Stop Overlay" test mode, that's a reasonable,
 * clearly documented compromise.
 */
class GamepadOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            addOverlayView()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start overlay", e)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            removeOverlayView()
        } catch (e: Exception) {
            Log.w(TAG, "Error while tearing down overlay", e)
        }
        super.onDestroy()
    }

    private fun addOverlayView() {
        if (!OverlayPermission.isGranted(this)) {
            Log.w(TAG, "Overlay permission not granted; not starting")
            stopSelf()
            return
        }

        val owner = OverlayLifecycleOwner().also { it.onCreate() }
        lifecycleOwner = owner

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                NovaGamepadTheme {
                    OverlayContent(onStop = { stopSelf() })
                }
            }
        }
        overlayView = composeView

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 200
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        wm.addView(composeView, params)
    }

    private fun removeOverlayView() {
        try {
            overlayView?.let { view -> windowManager?.removeView(view) }
        } catch (e: Exception) {
            Log.w(TAG, "Error removing overlay view", e)
        }
        lifecycleOwner?.onDestroy()
        overlayView = null
        windowManager = null
        lifecycleOwner = null
    }

    companion object {
        private const val TAG = "GamepadOverlayService"
    }
}
