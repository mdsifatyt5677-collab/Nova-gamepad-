package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.novagamepad.app.data.model.LayoutElement
import com.novagamepad.app.features.gamepad.model.EditorState
import com.novagamepad.app.features.gamepad.model.mappableControls
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaControllerOutline
import com.novagamepad.app.ui.theme.NovaTextSecondary
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Shown while an element is selected in Edit Mode: nudge its position with
 * the arrow pad, step its size/opacity, show/hide it, and — Day 4 — set
 * the keyboard key it's mapped to right here instead of needing the
 * separate full Mapping list. Deliberately just steppers and a small text
 * field, not sliders or a complicated editor.
 */
@Composable
fun EditPanel(
    element: LayoutElement,
    editor: EditorState,
    modifier: Modifier = Modifier
) {
    val nudge = 6.dp
    val isVisible = editor.isVisible(element)

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(NovaSurface)
            .border(1.dp, NovaControllerOutline, RoundedCornerShape(12.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = element.displayName,
                color = NovaWhite,
                style = MaterialTheme.typography.bodyMedium
            )
            IconButton(
                onClick = { editor.toggleVisible(element) },
                modifier = Modifier.size(24.dp).padding(start = 4.dp)
            ) {
                Icon(
                    imageVector = if (isVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                    contentDescription = if (isVisible) "Hide" else "Show",
                    tint = if (isVisible) NovaTextSecondary else NovaOrange,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            PanelIconButton(Icons.Filled.KeyboardArrowLeft) {
                editor.nudgeOffset(element, -nudge, 0.dp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PanelIconButton(Icons.Filled.KeyboardArrowUp) {
                    editor.nudgeOffset(element, 0.dp, -nudge)
                }
                PanelIconButton(Icons.Filled.KeyboardArrowDown) {
                    editor.nudgeOffset(element, 0.dp, nudge)
                }
            }
            PanelIconButton(Icons.Filled.KeyboardArrowRight) {
                editor.nudgeOffset(element, nudge, 0.dp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Stepper("Size", onMinus = { editor.adjustScale(element, -0.1f) }, onPlus = { editor.adjustScale(element, 0.1f) })
            Stepper("Opacity", onMinus = { editor.adjustOpacity(element, -0.1f) }, onPlus = { editor.adjustOpacity(element, 0.1f) })
        }

        // "Set Key" — Day 4: tap a button in Edit Mode, assign it a key,
        // right where you selected it. The D-pad has four rows (one per
        // direction); every other mappable element has exactly one.
        Column(modifier = Modifier.padding(top = 8.dp)) {
            Text("Set Key", color = NovaTextSecondary, style = MaterialTheme.typography.bodyMedium)
            for (control in element.mappableControls()) {
                MappingRow(control = control, editor = editor)
            }
        }
    }
}

@Composable
private fun PanelIconButton(icon: ImageVector, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(28.dp)) {
        Icon(imageVector = icon, contentDescription = null, tint = NovaOrange, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun Stepper(label: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = NovaTextSecondary, style = MaterialTheme.typography.bodyMedium)
        Row {
            IconButton(onClick = onMinus, modifier = Modifier.size(26.dp)) {
                Text("-", color = NovaWhite, style = MaterialTheme.typography.titleMedium)
            }
            IconButton(onClick = onPlus, modifier = Modifier.size(26.dp)) {
                Text("+", color = NovaWhite, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
