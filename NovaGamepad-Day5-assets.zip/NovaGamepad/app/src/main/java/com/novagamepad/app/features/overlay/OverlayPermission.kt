package com.novagamepad.app.features.overlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Checks and requests the "draw over other apps" permission the overlay
 * needs. This is the standard, documented SYSTEM_ALERT_WINDOW flow —
 * nothing here uses Accessibility Service, Shizuku, or root.
 */
object OverlayPermission {
    fun isGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    /** Intent that opens the system settings screen where the user grants the permission. */
    fun requestIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
    }
}
