package com.novagamepad.app.features.gamepad.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.Dp
import com.novagamepad.app.data.model.ControlTransform
import com.novagamepad.app.data.model.ControllerLayoutConfig
import com.novagamepad.app.data.model.JoystickSettings
import com.novagamepad.app.data.model.LayoutElement

/**
 * Day 3/4 customization state: whether Edit Mode is on, which element is
 * selected, every element's position/size/opacity/visibility, every
 * button's key mapping, plus the global size/opacity multipliers and
 * per-stick sensitivity/dead-zone. This is pure in-memory state —
 * [com.novagamepad.app.data.storage.ControllerLayoutStorage] is what
 * actually persists it; this class just knows how to turn itself into a
 * [ControllerLayoutConfig] and back.
 *
 * Created once in MainActivity and shared by the Settings screen and the
 * Gamepad Preview screen, so a change made in Settings (say, dragging the
 * sensitivity slider) is immediately reflected on the live controller.
 */
class EditorState {
    var isEditMode by mutableStateOf(false)
        private set

    var selectedElement by mutableStateOf<LayoutElement?>(null)
        private set

    /** Applies to every element on top of its own individual scale — the Settings screen's "Button Size" slider. */
    var globalScale by mutableStateOf(1f)
        private set

    /** Applies to every element on top of its own individual opacity — the Settings screen's "Button Opacity" slider. */
    var globalOpacity by mutableStateOf(1f)
        private set

    var leftStickSettings by mutableStateOf(JoystickSettings())
        private set

    var rightStickSettings by mutableStateOf(JoystickSettings())
        private set

    /** Backed by a snapshot state map so any composable reading one entry recomposes on change. */
    val transforms = mutableStateMapOf<LayoutElement, ControlTransform>()
    val mappings = mutableStateMapOf<GamepadControl, String>()

    /** An element with no stored transform yet is just at its Day 2 default (identity transform, visible). */
    fun transformOf(element: LayoutElement): ControlTransform =
        transforms[element] ?: ControlTransform()

    fun isVisible(element: LayoutElement): Boolean = transformOf(element).isVisible

    fun setEditMode(enabled: Boolean) {
        isEditMode = enabled
        if (!enabled) selectedElement = null
    }

    fun selectElement(element: LayoutElement) {
        selectedElement = element
    }

    fun clearSelection() {
        selectedElement = null
    }

    /** Moves an element by a delta, clamped to a bounded drag range so it can never be dragged fully off-screen. */
    fun nudgeOffset(element: LayoutElement, dx: Dp, dy: Dp) {
        val current = transformOf(element)
        val newX = (current.offsetXDp + dx.value).coerceIn(-MAX_OFFSET_DP, MAX_OFFSET_DP)
        val newY = (current.offsetYDp + dy.value).coerceIn(-MAX_OFFSET_DP, MAX_OFFSET_DP)
        transforms[element] = current.copy(offsetXDp = newX, offsetYDp = newY)
    }

    fun adjustScale(element: LayoutElement, delta: Float) {
        val current = transformOf(element)
        transforms[element] = current.copy(scale = (current.scale + delta).coerceIn(MIN_SCALE, MAX_SCALE))
    }

    fun adjustOpacity(element: LayoutElement, delta: Float) {
        val current = transformOf(element)
        transforms[element] = current.copy(opacity = (current.opacity + delta).coerceIn(MIN_OPACITY, 1f))
    }

    fun setVisible(element: LayoutElement, visible: Boolean) {
        transforms[element] = transformOf(element).copy(isVisible = visible)
    }

    fun toggleVisible(element: LayoutElement) {
        setVisible(element, !isVisible(element))
    }

    fun setGlobalScale(value: Float) {
        globalScale = value.coerceIn(MIN_SCALE, MAX_SCALE)
    }

    fun setGlobalOpacity(value: Float) {
        globalOpacity = value.coerceIn(MIN_OPACITY, 1f)
    }

    fun setLeftStickSensitivity(value: Float) {
        leftStickSettings = leftStickSettings.copy(sensitivity = value.coerceIn(MIN_SENSITIVITY, MAX_SENSITIVITY))
    }

    fun setLeftStickDeadzone(value: Float) {
        leftStickSettings = leftStickSettings.copy(deadzone = value.coerceIn(0f, MAX_DEADZONE))
    }

    fun setRightStickSensitivity(value: Float) {
        rightStickSettings = rightStickSettings.copy(sensitivity = value.coerceIn(MIN_SENSITIVITY, MAX_SENSITIVITY))
    }

    fun setRightStickDeadzone(value: Float) {
        rightStickSettings = rightStickSettings.copy(deadzone = value.coerceIn(0f, MAX_DEADZONE))
    }

    fun setMapping(control: GamepadControl, key: String) {
        if (key.isBlank()) {
            mappings.remove(control)
        } else {
            mappings[control] = key
        }
    }

    /** Restores every element to its Day 2 default position/size/opacity/visibility, and the global sliders to neutral. Mappings and joystick sensitivity/dead-zone are left untouched. */
    fun resetLayout() {
        transforms.clear()
        globalScale = 1f
        globalOpacity = 1f
    }

    fun toConfig(): ControllerLayoutConfig = ControllerLayoutConfig(
        transforms = transforms.toMap(),
        mappings = mappings.toMap(),
        globalScale = globalScale,
        globalOpacity = globalOpacity,
        leftStickSettings = leftStickSettings,
        rightStickSettings = rightStickSettings
    )

    /** Applies a loaded (or defaulted) config. Safe to call with an empty config — that's just "no customization yet". */
    fun loadFrom(config: ControllerLayoutConfig) {
        transforms.clear()
        transforms.putAll(config.transforms)
        mappings.clear()
        mappings.putAll(config.mappings)
        globalScale = config.globalScale
        globalOpacity = config.globalOpacity
        leftStickSettings = config.leftStickSettings
        rightStickSettings = config.rightStickSettings
    }

    companion object {
        private const val MAX_OFFSET_DP = 120f
        private const val MIN_SCALE = 0.6f
        private const val MAX_SCALE = 1.6f
        private const val MIN_OPACITY = 0.3f
        private const val MIN_SENSITIVITY = 0.3f
        private const val MAX_SENSITIVITY = 2f
        private const val MAX_DEADZONE = 0.5f
    }
}

@Composable
fun rememberEditorState(): EditorState = remember { EditorState() }
