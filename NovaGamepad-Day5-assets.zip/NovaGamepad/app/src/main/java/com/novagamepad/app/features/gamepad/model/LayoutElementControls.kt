package com.novagamepad.app.features.gamepad.model

import com.novagamepad.app.data.model.LayoutElement

/**
 * Which [GamepadControl](s) a selected [LayoutElement]'s "Set Key" section
 * should offer. Most elements map to exactly one control; the D-pad
 * covers all four directions; each joystick maps to its own click
 * (L3/R3) rather than to anything about its analog movement, since a
 * continuous axis isn't something a single keyboard key can represent.
 */
fun LayoutElement.mappableControls(): List<GamepadControl> = when (this) {
    LayoutElement.LEFT_JOYSTICK -> listOf(GamepadControl.STICK_LEFT_CLICK)
    LayoutElement.RIGHT_JOYSTICK -> listOf(GamepadControl.STICK_RIGHT_CLICK)
    LayoutElement.DPAD -> listOf(
        GamepadControl.DPAD_UP,
        GamepadControl.DPAD_DOWN,
        GamepadControl.DPAD_LEFT,
        GamepadControl.DPAD_RIGHT
    )
    LayoutElement.ACTION_A -> listOf(GamepadControl.ACTION_A)
    LayoutElement.ACTION_B -> listOf(GamepadControl.ACTION_B)
    LayoutElement.ACTION_X -> listOf(GamepadControl.ACTION_X)
    LayoutElement.ACTION_Y -> listOf(GamepadControl.ACTION_Y)
    LayoutElement.SHOULDER_LT -> listOf(GamepadControl.SHOULDER_LT)
    LayoutElement.SHOULDER_LB -> listOf(GamepadControl.SHOULDER_LB)
    LayoutElement.SHOULDER_RT -> listOf(GamepadControl.SHOULDER_RT)
    LayoutElement.SHOULDER_RB -> listOf(GamepadControl.SHOULDER_RB)
}
