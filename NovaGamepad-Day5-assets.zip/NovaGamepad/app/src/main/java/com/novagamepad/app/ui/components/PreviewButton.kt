package com.novagamepad.app.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaBackground
import com.novagamepad.app.ui.theme.NovaOrange

/**
 * Bottom call-to-action. Fixed, comfortable width rather than a screen-width
 * fraction so it reads correctly in the wide landscape frame instead of
 * stretching edge to edge. Opens the Day 2 gamepad preview screen.
 */
@Composable
fun PreviewButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .widthIn(min = 200.dp, max = 260.dp)
            .height(50.dp),
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = NovaOrange,
            contentColor = NovaBackground
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
        contentPadding = PaddingValues(horizontal = 20.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.PlayArrow,
            contentDescription = null,
            modifier = Modifier.width(18.dp).height(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Preview",
            style = MaterialTheme.typography.labelLarge
        )
    }
}
