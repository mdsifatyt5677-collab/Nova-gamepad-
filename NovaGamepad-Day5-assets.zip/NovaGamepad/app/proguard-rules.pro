# Add project specific ProGuard rules here.
# Nova Gamepad does not enable minification for the Day 1 debug build.
