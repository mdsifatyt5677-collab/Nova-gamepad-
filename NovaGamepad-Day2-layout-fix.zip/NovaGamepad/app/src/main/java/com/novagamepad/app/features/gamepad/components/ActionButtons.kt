package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * A/B/X/Y arranged in the classic diamond: Y top, X left, B right, A
 * bottom — matching the reference. Large, circular, outlined buttons (no
 * filled background) for comfortable touch targets.
 */
@Composable
fun ActionButtons(
    size: Dp,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier
) {
    val cell = size * 0.46f

    Box(modifier = modifier.size(size)) {
        ActionButton(GamepadControl.ACTION_Y, uiState, Modifier.align(Alignment.TopCenter).size(cell))
        ActionButton(GamepadControl.ACTION_A, uiState, Modifier.align(Alignment.BottomCenter).size(cell))
        ActionButton(GamepadControl.ACTION_X, uiState, Modifier.align(Alignment.CenterStart).size(cell))
        ActionButton(GamepadControl.ACTION_B, uiState, Modifier.align(Alignment.CenterEnd).size(cell))
    }
}

@Composable
private fun ActionButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    modifier: Modifier
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = CircleShape,
        modifier = modifier
    ) {
        Text(
            text = control.label,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}
