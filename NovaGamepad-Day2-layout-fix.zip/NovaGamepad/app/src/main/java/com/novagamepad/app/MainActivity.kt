package com.novagamepad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.novagamepad.app.features.gamepad.GamepadPreviewScreen
import com.novagamepad.app.ui.screens.home.HomeScreen
import com.novagamepad.app.ui.theme.NovaGamepadTheme

/** The app's two Day 2 destinations. */
private enum class NovaScreen { Home, GamepadPreview }

/**
 * Single-activity entry point. Screen switching is a plain in-memory state
 * flag rather than a navigation library — with only two destinations,
 * Navigation-Compose would be unused weight. If Day 3 adds a profile
 * editor or settings screen, this is the seam to swap in real navigation
 * without touching the screens themselves.
 *
 * The window is also put into true immersive fullscreen here (status bar
 * and navigation bar hidden, content drawn edge-to-edge) automatically on
 * every device — there is no phone/tablet mode to pick, the same code
 * adapts to whatever screen it runs on.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()

        setContent {
            NovaGamepadTheme {
                var screen by remember { mutableStateOf(NovaScreen.Home) }

                when (screen) {
                    NovaScreen.Home -> HomeScreen(
                        onPreviewClick = { screen = NovaScreen.GamepadPreview }
                    )
                    NovaScreen.GamepadPreview -> GamepadPreviewScreen(
                        onBack = { screen = NovaScreen.Home }
                    )
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BY_SWIPE_GESTURE
    }
}
