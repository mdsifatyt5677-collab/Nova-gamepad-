package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * Small circular stick-click button (LS / RS), positioned above the
 * action-button diamond in the reference layout.
 */
@Composable
fun StickButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    size: Dp,
    modifier: Modifier = Modifier
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = CircleShape,
        modifier = modifier.size(size)
    ) {
        Text(
            text = control.label,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
