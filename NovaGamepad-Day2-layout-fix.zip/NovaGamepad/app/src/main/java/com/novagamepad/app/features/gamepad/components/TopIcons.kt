package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterNone
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaSurfaceOutline
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Top-left "utility" icon from the reference. Doubles as the way back to
 * Home for now — the reference has no separate back arrow, and adding one
 * would mean introducing an element that isn't in the reference. The
 * Android system Back gesture/button still works everywhere via
 * [androidx.activity.compose.BackHandler] regardless of this icon.
 */
@Composable
fun UtilityIconButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .border(1.dp, NovaSurfaceOutline, CircleShape)
    ) {
        Icon(
            imageVector = Icons.Outlined.FilterNone,
            contentDescription = "Back to Home",
            tint = NovaWhite,
            modifier = Modifier.size(16.dp)
        )
    }
}

/** Static "⌨ Keyboard" indicator from the top-center of the reference. */
@Composable
fun KeyboardIndicator(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, NovaSurfaceOutline, RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.Keyboard,
            contentDescription = null,
            tint = NovaWhite,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = "Keyboard",
            style = MaterialTheme.typography.bodyMedium,
            color = NovaWhite,
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

/**
 * The top-right three-line ("hamburger") icon. Tapping it hides or shows
 * the debug status box (Pressed: / Joystick: readout) — it doesn't affect
 * the controller itself.
 */
@Composable
fun StatusToggleButton(
    isStatusVisible: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onToggle,
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .border(1.dp, if (isStatusVisible) NovaOrange else NovaSurfaceOutline, CircleShape)
    ) {
        Icon(
            imageVector = Icons.Outlined.Menu,
            contentDescription = "Toggle status box",
            tint = if (isStatusVisible) NovaOrange else NovaWhite,
            modifier = Modifier.size(18.dp)
        )
    }
}

private val HexagonShape: Shape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    moveTo(w * 0.5f, 0f)
    lineTo(w, h * 0.25f)
    lineTo(w, h * 0.75f)
    lineTo(w * 0.5f, h)
    lineTo(0f, h * 0.75f)
    lineTo(0f, h * 0.25f)
    close()
}

/** Small decorative Nova brand mark, far top-right in the reference. */
@Composable
fun NovaHexMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(30.dp)
            .clip(HexagonShape)
            .border(1.dp, NovaSurfaceOutline, HexagonShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(NovaOrange)
        )
    }
}
