package com.novagamepad.app.features.gamepad.model

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

/**
 * Local, in-memory state for the gamepad preview: which control is
 * currently pressed, each stick's normalized -1..1 offset, which element
 * is "selected" (subtle selection border), and whether the debug status
 * box is currently visible. Nothing here is persisted or mapped to real
 * input yet — Day 3 backs this with a real per-profile layout and
 * key-mapping model.
 */
class GamepadUiState {
    var pressed by mutableStateOf<GamepadControl?>(null)
        private set

    var selected by mutableStateOf<GamepadControl?>(null)
        private set

    var leftStickX by mutableFloatStateOf(0f)
        private set

    var leftStickY by mutableFloatStateOf(0f)
        private set

    var rightStickX by mutableFloatStateOf(0f)
        private set

    var rightStickY by mutableFloatStateOf(0f)
        private set

    /** Whether the "Pressed: / Joystick:" debug readout is showing. */
    var statusVisible by mutableStateOf(true)
        private set

    fun press(control: GamepadControl) {
        pressed = control
        selected = control
    }

    fun release(control: GamepadControl) {
        if (pressed == control) pressed = null
    }

    /** Called by a [com.novagamepad.app.features.gamepad.components.Joystick] while it's being dragged. */
    fun updateStick(control: GamepadControl, x: Float, y: Float) {
        when (control) {
            GamepadControl.JOYSTICK_LEFT -> {
                leftStickX = x
                leftStickY = y
            }
            GamepadControl.JOYSTICK_RIGHT -> {
                rightStickX = x
                rightStickY = y
            }
            else -> Unit
        }
        if (x != 0f || y != 0f) {
            selected = control
        }
    }

    /** Toggled by the top-right three-line button to hide/show the debug status box. */
    fun toggleStatusOverlay() {
        statusVisible = !statusVisible
    }
}

@Composable
fun rememberGamepadUiState(): GamepadUiState = remember { GamepadUiState() }
