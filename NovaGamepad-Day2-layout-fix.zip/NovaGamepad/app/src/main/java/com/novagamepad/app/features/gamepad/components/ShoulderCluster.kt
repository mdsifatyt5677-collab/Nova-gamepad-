package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState

/**
 * A shoulder-button pair (LT above/outside, LB below/inside), tilted at an
 * angle the way they sit in the reference image — instead of a plain
 * horizontal row. [mirrored] flips the whole cluster for the right side
 * (RT/RB), so the two sides fan outward symmetrically.
 */
@Composable
fun ShoulderCluster(
    outerControl: GamepadControl,
    innerControl: GamepadControl,
    uiState: GamepadUiState,
    mirrored: Boolean,
    modifier: Modifier = Modifier
) {
    val sign = if (mirrored) -1f else 1f
    val corner = RoundedCornerShape(16.dp)
    val buttonWidth = 84.dp
    val buttonHeight = 72.dp

    Box(modifier = modifier.size(150.dp, 150.dp)) {
        ShoulderButton(
            control = outerControl,
            uiState = uiState,
            shape = corner,
            width = buttonWidth,
            height = buttonHeight,
            modifier = Modifier
                .align(if (mirrored) Alignment.TopEnd else Alignment.TopStart)
                .offset(x = 4.dp * sign, y = 4.dp)
                .rotate(sign * -22f)
        )
        ShoulderButton(
            control = innerControl,
            uiState = uiState,
            shape = corner,
            width = buttonWidth,
            height = buttonHeight,
            modifier = Modifier
                .align(if (mirrored) Alignment.TopEnd else Alignment.TopStart)
                .offset(x = 42.dp * sign, y = 62.dp)
                .rotate(sign * 20f)
        )
    }
}

@Composable
private fun ShoulderButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    shape: RoundedCornerShape,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier
) {
    GamepadButton(
        control = control,
        uiState = uiState,
        shape = shape,
        modifier = modifier.size(width = width, height = height)
    ) {
        Text(
            text = control.label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
        )
    }
}
