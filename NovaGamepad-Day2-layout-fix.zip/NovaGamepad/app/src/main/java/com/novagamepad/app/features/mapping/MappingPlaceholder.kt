package com.novagamepad.app.features.mapping

// Button-to-key/touch mapping definitions and the mapping editor will live here.
// Intentionally empty on Day 1 — see PROJECT sprint plan.
// This package exists so the module boundary is in place before
// implementation starts, keeping later work additive rather than a rewrite.
