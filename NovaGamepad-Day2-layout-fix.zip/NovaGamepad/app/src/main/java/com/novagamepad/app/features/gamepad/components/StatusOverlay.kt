package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novagamepad.app.features.gamepad.model.GamepadUiState
import com.novagamepad.app.ui.theme.NovaSurface
import com.novagamepad.app.ui.theme.NovaTextSecondary
import java.util.Locale

/**
 * Testing/debug readout only — shows what's currently pressed and both
 * sticks' raw values. Hidden/shown via the top-right three-line button
 * ([GamepadUiState.statusVisible]); the caller decides whether to compose
 * this at all.
 */
@Composable
fun StatusOverlay(
    uiState: GamepadUiState,
    modifier: Modifier = Modifier
) {
    val pressedLabel = uiState.pressed?.label ?: "None"
    val leftText = String.format(
        Locale.US, "Left Joystick: X %.2f | Y %.2f", uiState.leftStickX, uiState.leftStickY
    )
    val rightText = String.format(
        Locale.US, "Right Joystick: X %.2f | Y %.2f", uiState.rightStickX, uiState.rightStickY
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(NovaSurface.copy(alpha = 0.85f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text("Pressed: $pressedLabel", color = NovaTextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Text(leftText, color = NovaTextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Text(rightText, color = NovaTextSecondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}
