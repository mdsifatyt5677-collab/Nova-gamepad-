package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaSurfaceElevated
import com.novagamepad.app.ui.theme.NovaSurfaceOutline
import com.novagamepad.app.ui.theme.NovaTextSecondary
import com.novagamepad.app.ui.theme.NovaWhite
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Large virtual analog joystick matching the reference: a thin-outlined,
 * dark/transparent base, small directional tick marks around the edge, and
 * a small dark knob (optionally carrying a center label, e.g. "R" for the
 * right stick). The knob tracks the finger 1:1 within the base, is clamped
 * so it can never leave the circle, and snaps back to center on release,
 * reporting a normalized -1..1 x/y through [GamepadUiState.updateStick].
 *
 * [control] must be [GamepadControl.JOYSTICK_LEFT] or
 * [GamepadControl.JOYSTICK_RIGHT] — each stick is fully independent, so two
 * of these can be on screen and dragged at the same time.
 */
@Composable
fun Joystick(
    diameter: Dp,
    control: GamepadControl,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier,
    centerLabel: String? = null
) {
    val density = LocalDensity.current
    val knobFraction = 0.34f
    val radiusPx = with(density) { (diameter / 2).toPx() }
    val knobRadiusPx = with(density) { (diameter * knobFraction / 2).toPx() }
    val maxOffsetPx = radiusPx - knobRadiusPx

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val isSelected = uiState.selected == control

    fun resetKnob() {
        offsetX = 0f
        offsetY = 0f
        uiState.updateStick(control, 0f, 0f)
    }

    Box(
        modifier = modifier
            .size(diameter)
            .clip(CircleShape)
            .background(Color.Transparent)
            .border(
                width = if (isSelected) 2.dp else 1.5.dp,
                color = if (isSelected) NovaOrange else NovaSurfaceOutline,
                shape = CircleShape
            )
            .pointerInput(control) {
                detectDragGestures(
                    onDragStart = {
                        uiState.updateStick(control, offsetX / maxOffsetPx, -offsetY / maxOffsetPx)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newX = offsetX + dragAmount.x
                        val newY = offsetY + dragAmount.y
                        val distance = sqrt(newX * newX + newY * newY)
                        if (distance > maxOffsetPx && distance > 0f) {
                            val scale = maxOffsetPx / distance
                            offsetX = newX * scale
                            offsetY = newY * scale
                        } else {
                            offsetX = newX
                            offsetY = newY
                        }
                        // Y is inverted so "up" on screen reports as positive.
                        uiState.updateStick(control, offsetX / maxOffsetPx, -offsetY / maxOffsetPx)
                    },
                    onDragEnd = { resetKnob() },
                    onDragCancel = { resetKnob() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Small directional tick marks around the edge — decorative only,
        // the drag gesture on the whole base handles actual direction.
        Icon(
            imageVector = Icons.Filled.KeyboardArrowUp,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.TopCenter).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.BottomCenter).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowLeft,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.CenterStart).size(16.dp)
        )
        Icon(
            imageVector = Icons.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = NovaTextSecondary,
            modifier = Modifier.align(Alignment.CenterEnd).size(16.dp)
        )

        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(diameter * knobFraction)
                .clip(CircleShape)
                .background(NovaSurfaceElevated)
                .border(1.dp, NovaSurfaceOutline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (centerLabel != null) {
                Text(
                    text = centerLabel,
                    color = NovaWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
