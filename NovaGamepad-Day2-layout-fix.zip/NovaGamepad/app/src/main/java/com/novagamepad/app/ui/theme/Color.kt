package com.novagamepad.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core palette. Kept small and named so future screens (profiles, controller
// editor, settings) reuse the same tokens instead of inventing new colors.
val NovaBackground = Color(0xFF0E0D12)
val NovaSurface = Color(0xFF17151D)
val NovaSurfaceElevated = Color(0xFF1D1A24)
val NovaSurfaceOutline = Color(0xFF2B2833)
val NovaOrange = Color(0xFFFF7A1A)
val NovaOrangeDim = Color(0xFF8A4212)
val NovaOrangeSoft = Color(0x26FF7A1A)
val NovaWhite = Color(0xFFF5F4F7)
val NovaTextSecondary = Color(0xFF9A96A5)
