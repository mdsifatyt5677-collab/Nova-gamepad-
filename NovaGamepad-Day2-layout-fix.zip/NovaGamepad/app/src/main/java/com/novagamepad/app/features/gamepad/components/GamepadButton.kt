package com.novagamepad.app.features.gamepad.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.GamepadUiState
import com.novagamepad.app.ui.theme.NovaOrange
import com.novagamepad.app.ui.theme.NovaOrangeSoft
import com.novagamepad.app.ui.theme.NovaSurfaceOutline
import com.novagamepad.app.ui.theme.NovaWhite

/**
 * Single reusable control surface used for every button on the gamepad
 * preview — action buttons, D-pad arrows, shoulder buttons, LS/RS. Styled
 * to match the reference layout: transparent/dark interior with a thin
 * light outline at rest. Orange is used only as brief interaction
 * feedback (a subtle tint + brighter border while pressed, a thin border
 * while selected) — never as a large filled background.
 */
@Composable
fun GamepadButton(
    control: GamepadControl,
    uiState: GamepadUiState,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    content: @Composable () -> Unit
) {
    val isPressed = uiState.pressed == control
    val isSelected = uiState.selected == control

    val borderColor = if (isPressed || isSelected) NovaOrange else NovaSurfaceOutline
    val borderWidth = if (isPressed) 2.dp else 1.dp
    val backgroundColor = if (isPressed) NovaOrangeSoft else Color.Transparent

    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(width = borderWidth, color = borderColor, shape = shape)
            .pointerInput(control) {
                detectTapGestures(
                    onPress = {
                        uiState.press(control)
                        tryAwaitRelease()
                        uiState.release(control)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides NovaWhite) {
            content()
        }
    }
}
