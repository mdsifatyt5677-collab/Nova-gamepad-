package com.novagamepad.app.features.gamepad

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novagamepad.app.features.gamepad.components.ActionButtons
import com.novagamepad.app.features.gamepad.components.DPad
import com.novagamepad.app.features.gamepad.components.Joystick
import com.novagamepad.app.features.gamepad.components.KeyboardIndicator
import com.novagamepad.app.features.gamepad.components.NovaHexMark
import com.novagamepad.app.features.gamepad.components.ShoulderCluster
import com.novagamepad.app.features.gamepad.components.StatusOverlay
import com.novagamepad.app.features.gamepad.components.StatusToggleButton
import com.novagamepad.app.features.gamepad.components.StickButton
import com.novagamepad.app.features.gamepad.components.UtilityIconButton
import com.novagamepad.app.features.gamepad.model.GamepadControl
import com.novagamepad.app.features.gamepad.model.rememberGamepadUiState
import com.novagamepad.app.ui.theme.NovaBackground

/**
 * Gamepad preview / test controller, laid out to match the reference
 * image: LT/LB tilted in the top-left corner, RT/RB mirrored top-right,
 * a utility icon / Keyboard indicator / status-toggle / Nova mark along
 * the very top edge, and — across the bottom — left joystick + D-pad on
 * one side, right joystick + LS/RS + action-button diamond on the other.
 *
 * Purely a local UI surface — nothing here touches real input, other
 * apps, or an overlay service. Everything is sized from the available
 * screen at runtime (off the shorter dimension) so the same layout holds
 * its relative proportions across phones and tablets.
 */
@Composable
fun GamepadPreviewScreen(onBack: () -> Unit) {
    val uiState = rememberGamepadUiState()

    BackHandler(onBack = onBack)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val shorterSide = if (maxWidth < maxHeight) maxWidth else maxHeight

        val stickDiameter = (shorterSide * 0.40f).coerceIn(120.dp, 180.dp)
        val dPadSize = (shorterSide * 0.30f).coerceIn(84.dp, 130.dp)
        val actionSize = (shorterSide * 0.34f).coerceIn(110.dp, 165.dp)
        val stickButtonSize = 40.dp
        val sidePadding = if (maxWidth > 700.dp) 36.dp else 16.dp

        // ---- Top edge: utility icon · Keyboard · status toggle · Nova mark ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = sidePadding, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            UtilityIconButton(onClick = onBack)
            KeyboardIndicator()
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusToggleButton(
                    isStatusVisible = uiState.statusVisible,
                    onToggle = { uiState.toggleStatusOverlay() }
                )
                NovaHexMark()
            }
        }

        // ---- Shoulder clusters, tilted, fanning out from the top corners ----
        ShoulderCluster(
            outerControl = GamepadControl.SHOULDER_LT,
            innerControl = GamepadControl.SHOULDER_LB,
            uiState = uiState,
            mirrored = false,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 4.dp, top = 46.dp)
        )
        ShoulderCluster(
            outerControl = GamepadControl.SHOULDER_RT,
            innerControl = GamepadControl.SHOULDER_RB,
            uiState = uiState,
            mirrored = true,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 4.dp, top = 46.dp)
        )

        // ---- Bottom: left joystick + D-pad  <->  right joystick + LS/RS + diamond ----
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = sidePadding, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                Joystick(
                    diameter = stickDiameter,
                    control = GamepadControl.JOYSTICK_LEFT,
                    uiState = uiState
                )
                DPad(
                    size = dPadSize,
                    uiState = uiState,
                    modifier = Modifier.padding(start = 20.dp)
                )
            }

            Row(verticalAlignment = Alignment.Bottom) {
                Joystick(
                    diameter = stickDiameter,
                    control = GamepadControl.JOYSTICK_RIGHT,
                    uiState = uiState,
                    centerLabel = "R"
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(start = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.width(actionSize),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StickButton(GamepadControl.STICK_LEFT_CLICK, uiState, stickButtonSize)
                        StickButton(GamepadControl.STICK_RIGHT_CLICK, uiState, stickButtonSize)
                    }
                    ActionButtons(
                        size = actionSize,
                        uiState = uiState,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }

        if (uiState.statusVisible) {
            StatusOverlay(
                uiState = uiState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 6.dp)
            )
        }
    }
}
