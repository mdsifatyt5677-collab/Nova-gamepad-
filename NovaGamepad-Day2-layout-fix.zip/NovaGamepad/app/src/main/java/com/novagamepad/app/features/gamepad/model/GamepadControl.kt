package com.novagamepad.app.features.gamepad.model

/**
 * Stable identifier for every touchable element on the gamepad preview.
 * Used for press/selection state today; Day 3's key-mapping and layout
 * editor will key their data off the same enum instead of raw strings.
 */
enum class GamepadControl(val label: String) {
    ACTION_A("A"),
    ACTION_B("B"),
    ACTION_X("X"),
    ACTION_Y("Y"),
    DPAD_UP("Up"),
    DPAD_DOWN("Down"),
    DPAD_LEFT("Left"),
    DPAD_RIGHT("Right"),
    SHOULDER_LB("LB"),
    SHOULDER_LT("LT"),
    SHOULDER_RB("RB"),
    SHOULDER_RT("RT"),
    STICK_LEFT_CLICK("LS"),
    STICK_RIGHT_CLICK("RS"),
    JOYSTICK_LEFT("Left Joystick"),
    JOYSTICK_RIGHT("Right Joystick")
}
