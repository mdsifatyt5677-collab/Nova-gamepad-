package com.novagamepad.app.features.overlay

// The floating overlay service (drawn over other apps) will live here. Requires SYSTEM_ALERT_WINDOW + a foreground Service — not implemented yet.
// Intentionally empty on Day 1 — see PROJECT sprint plan.
// This package exists so the module boundary is in place before
// implementation starts, keeping later work additive rather than a rewrite.
